import os
import sys
from pathlib import Path
from app.core.config import Settings

ROOT = Path.cwd()
P7_DIR = ROOT / "output" / "evaluation-v3" / "p7-trace-20261012-r3"
OUTPUT_DIR = ROOT / "output" / "evaluation-v3" / "heldout-trace-20261012-r3"
DATABASE_URL = "postgresql+psycopg://postgres:@127.0.0.1:55433/evaluation"
RUNTIME_MANIFEST = ROOT / "output" / "review-remediation" / "live-runtime-manifest.v2.json"
RUN_ID = "run_p8_trace_20261012_r3"
settings = Settings()
api_key = settings.openai_api_key_value
if not api_key:
    raise RuntimeError("OPENAI_API_KEY is not configured")
os.environ.update({
    "OPENAI_API_KEY": api_key, "DATABASE_URL": DATABASE_URL, "MODEL_RUNTIME_MODE": "required",
    "OPENAI_MODEL": "gpt-5.4-mini-2026-03-17", "OPENAI_ROUTING_MODEL": "gpt-5.4-mini-2026-03-17",
    "OPENAI_PLANNING_MODEL": "gpt-5.4-mini-2026-03-17", "OPENAI_SPECIALIST_MODEL": "gpt-5.4-mini-2026-03-17",
    "OPENAI_SYNTHESIS_MODEL": "gpt-5.4-mini-2026-03-17", "EMBEDDING_BACKEND": "openai",
    "OPENAI_EMBEDDING_MODEL": "text-embedding-3-small", "OPENAI_EMBEDDING_DIMENSIONS": "1536",
    "V2_CORPUS_VERSION_ID": "cor_eeb982b0fe5cc975c10ea64ea036ebd93c34d51de31012484c28dfe65a4d",
    "V2_INDEX_MANIFEST_ID": "idx_deb43ea4281d908581b73f624db6e735a371816267f990731ca935808f5f",
    "V2_BUDGET_ACCOUNT_ID": "thanh-v2-provider-global", "OPENAI_CIRCUIT_FAILURE_THRESHOLD": "20",
    "OPENAI_MAX_CONCURRENCY": "2",
})

from app.evaluation import benchmark_cli

args = [
    "operate", "--project-root", str(ROOT), "--run-id", RUN_ID,
    "--successor-binding", str(P7_DIR / "successor-binding.v3.json"),
    "--p7-protocol", str(P7_DIR / "protocol.v3.json"),
    "--p7-repeat-decision", str(P7_DIR / "repeat-decision.v3.json"),
    "--p7-runtime-manifest", str(RUNTIME_MANIFEST), "--allow-network",
    "--database-url", DATABASE_URL, "--output", str(OUTPUT_DIR),
    "--checkpoint", str(OUTPUT_DIR / "heldout-checkpoint.v3.jsonl"),
    "--pilot-checkpoint", str(P7_DIR / "pilot-checkpoint.v3.jsonl"),
    "--pilot-schedule", str(P7_DIR / "pilot-schedule.v3.json"),
    "--export-reference-cases", str(OUTPUT_DIR / "independent-reference-cases.p8.json"),
    "--judge-budget-nano-usd", "50000000000",
]
code = benchmark_cli.cli(args)
if code != 0:
    sys.exit(code)
